import { Component } from '@angular/core';
export class AppComponent {
}
AppComponent.decorators = [
    { type: Component, args: [{
                selector: 'app-root',
                template: `<router-outlet></router-outlet>`
            },] },
];
/** @nocollapse */
AppComponent.ctorParameters = () => [];
