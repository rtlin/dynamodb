import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    template: `<app-home></app-home>`
})
export class AppComponent {

}